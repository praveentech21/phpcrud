-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2023 at 12:11 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `personalized`
--

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `content_id` int(10) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `c_title` varchar(50) NOT NULL,
  `c_about` varchar(200) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `topic_name` varchar(25) NOT NULL,
  `difficulty_level` varchar(10) NOT NULL,
  `learning_intelligence` varchar(10) NOT NULL,
  `content_type` varchar(10) NOT NULL,
  `video_path` varchar(150) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`content_id`, `teacher_name`, `c_title`, `c_about`, `subject`, `topic_name`, `difficulty_level`, `learning_intelligence`, `content_type`, `video_path`, `timestamp`) VALUES
(1, 'B.Tejesh', 'Introduction to JS - why JS -use of JS', 'Know  basic of Javascript', 'Web Techno', 'JAVASCRIPT', '0', 'visual', 'video', 'uploads/Javascript Introduction _ Lecture 1 _ Web Development Course.mp4', '2023-09-22 21:36:19'),
(2, 'B.Tejesh', 'IDE for JS , special-buttons', 'IDEs for javascript and tags', 'Web Techno', 'JAVASCRIPT', '0', 'visual', 'video', 'uploads/Javascript - First Program Namaste World _ Lecture 2 _ Web Development Course.mp4', '2023-09-22 21:36:19'),
(3, 'B.Tejesh', 'Add JS to web pages', 'ways to add javascript to web pages', 'Web Techno', 'JAVASCRIPT', '0', 'verbal', 'video', 'uploads/Ways to add JavaScript to Web Pages_ JavaScript _ Lecture 5 @ApnaCollegeOfficial.mp4', '2023-09-22 21:36:19'),
(4, 'B.Tejesh', 'if else and switch statments in JS', 'combined if else and switch statments', 'Web Techno', 'JAVASCRIPT', '0', 'verbal', 'video', 'uploads/Javascript _ Lecture 9 & 10 combined _ If else and switch statements _ Web Development Course.mp4', '2023-09-22 21:36:19'),
(5, 'B.Tejesh', 'Introduction to MYSQL', 'What is mysql-types of databases', 'Web Techno', 'MYSQL', '1', 'visual', 'video', 'uploads/What is MySQL_ _ Types of Database & How to Create It_ _ MySQL Tutorial for Beginners (1).mp4', '2023-09-22 21:36:19'),
(6, 'B.Tejesh', 'Installation of MYSQL', 'How to instal MYSQL', 'Web Techno', 'MYSQL', '1', 'visual', 'video', 'uploads/How to Install MySQL (Server and Workbench) - Latest Version (1).mp4', '2023-09-22 21:36:19'),
(7, 'B.Tejesh', 'Creation of Table in MYSQL', 'How to create a table in MYSQL', 'Web Techno', 'MYSQL', '1', 'verbal', 'video', 'uploads/How to Create a Table in MySQL_ _ MySQL Tutorial for Beginners (2).mp4', '2023-09-22 21:36:19'),
(8, 'B.Tejesh', 'Add data into Table in MYSQL', 'Add data into MYSQL using INSERT query', 'Web Techno', 'MYSQL', '1', 'verbal', 'video', 'uploads/MySQL Add Data Into Tables using the INSERT Query _ MySQL Tutorial for Beginners.mp4', '2023-09-22 21:36:19'),
(9, 'B.Tejesh', 'Installation of PHP', 'Installation of PHP and what are web servers', 'Web Techno', 'PHP', '1', 'visual', 'video', 'uploads/How To Install PHP & What Are Web Servers - PHP 8 Tutorial.mp4', '2023-09-22 21:36:19'),
(10, 'B.Tejesh', 'Basic PHP Syntax', 'Basic PHP Syntax ', 'Web Techno', 'PHP', '1', 'visual', 'video', 'uploads/Basic PHP Syntax - PHP 8 Tutorial.mp4', '2023-09-22 21:36:19'),
(11, 'B.Tejesh', 'Constants and Variables in PHP', 'Constants and Variables in PHP', 'Web Techno', 'PHP', '1', 'verbal', 'video', 'uploads/What Are Constants & Variable Variables In PHP - Full PHP 8 Tutorial.mp4', '2023-09-22 21:36:19'),
(12, 'B.Tejesh', 'Data Types and Type-casting overview in PHP', 'Data Types and Type-casting overview in php', 'Web Techno', 'PHP', '1', 'verbal', 'video', 'uploads/PHP Data Types - Typecasting Overview & How It Works - Full PHP 8 Tutorial.mp4', '2023-09-22 21:36:19'),
(13, 'B.Tejesh', 'Introduction to REACTJS', 'Introduction to REACTJS', 'Web Techno', 'REACTJS', '2', 'visual', 'video', 'uploads/ReactJS Tutorial - 1 - Introduction.mp4', '2023-09-22 21:36:19'),
(14, 'B.Tejesh', 'Run ReactJs project', 'setting up and run reactjs project ', 'Web Techno', 'REACTJS', '2', 'visual', 'video', 'uploads/ReactJS Tutorial - 2 - Hello World.mp4', '2023-09-22 21:36:19'),
(15, 'B.Tejesh', 'Folder Structure in ReactJs', 'Folder Structure in ReactJs', 'Web Techno', 'REACTJS', '2', 'verbal', 'video', 'uploads/ReactJS Tutorial - 3 - Folder Structure.mp4', '2023-09-22 21:36:19'),
(16, 'B.Tejesh', 'Functional Components in ReactJs', 'Functional Components in ReactJs', 'Web Techno', 'REACTJS', '2', 'verbal', 'video', 'uploads/ReactJS Tutorial - 5 - Functional Components.mp4', '2023-09-22 21:36:19'),
(17, 'B.Tejesh', 'Introduction to NODEJS', 'Introduction to NODEJS', 'Web Techno', 'NODEJS', '2', 'visual', 'video', 'uploads/Node js tutorial #1 what is Node js _ Introduction.mp4', '2023-09-22 21:36:19'),
(18, 'B.Tejesh', 'Use of NODEJS and basic points', 'Use of NODEJS and basic points', 'Web Techno', 'NODEJS', '2', 'visual', 'video', 'uploads/Node JS Tutorial #2 Basic Point Before Start with Code.mp4', '2023-09-22 21:36:19'),
(19, 'B.Tejesh', 'Installation of NODEJS', 'Installation of NODEJS', 'Web Techno', 'NODEJS', '2', 'verbal', 'video', 'uploads/Node JS tutorial #3 Install node , NPM.mp4', '2023-09-22 21:36:19'),
(20, 'B.Tejesh', 'Script with NODEJS', 'Script with NODEJS make first project', 'Web Techno', 'NODEJS', '2', 'verbal', 'video', 'uploads/Node JS tutorial #4 Make First Program.mp4', '2023-09-22 21:36:19'),
(21, 'R.Sahithi Pallavi', 'Abstract classes, interfaces', 'Python support for advanced object-oriented programming concepts opens up a world of possibilities for developers', 'Python', 'Advanced OOP', '2', 'logical', 'video', 'uploads/Object-oriented Programming in 7 minutes _ Mosh.mp4', '2023-09-22 21:39:24'),
(22, 'R.Sahithi Pallavi', 'Abstract classes, interfaces', 'Python support for advanced object-oriented programming concepts opens up a world of possibilities for developers', 'Python', 'Advanced OOP', '2', 'logical', 'video', 'uploads/Python abstract classes 👻.mp4', '2023-09-22 21:39:24'),
(23, 'R.Sahithi Pallavi', 'closures and advanced decorator usage', 'Closures are also used to implement decorators in Python', 'Python', 'Closures, Decorators', '2', 'visual', 'video', 'uploads/videoplayback.mp4', '2023-09-22 21:39:24'),
(24, 'R.Sahithi Pallavi', 'closures and advanced decorator usage', 'Closures are also used to implement decorators in Python', 'Python', 'Closures, Decorators', '2', 'visual', 'video', 'uploads/#44 Python Tutorial for Beginners _ Decorators.mp4', '2023-09-22 21:39:24'),
(25, 'R.Sahithi Pallavi', 'closures and advanced decorator usage', 'Closures are also used to implement decorators in Python', 'Python', 'Closures, Decorators', '2', 'logical', 'video', 'uploads/Closures in Python _ Closures in Python Hindi _ What is Closure in Python.mp4', '2023-09-22 21:39:24'),
(26, 'R.Sahithi Pallavi', 'closures and advanced decorator usage', 'Closures are also used to implement decorators in Python', 'Python', 'Closures, Decorators', '2', 'logical', 'video', 'uploads/Python Closures and Decorators _ Quick Tutorial.mp4', '2023-09-22 21:39:24'),
(27, 'R.Sahithi Pallavi', 'Class creation and behavior', 'A metaclass is a class that allows for other classes to be instantiated as objects of the metaclas', 'Python', 'Metaclasses', '2', 'verbal', 'video', 'uploads/What are metaclasses in Python_.mp4', '2023-09-22 21:39:24'),
(28, 'R.Sahithi Pallavi', 'Advanced techniques', 'The dictionary definition of concurrency is simultaneous occurrence', 'Python', 'Concurrency ,Parallelism', '2', 'verbal', 'video', 'uploads/Threading Tutorial #1 - Concurrency, Threading and Parallelism Explained.mp4', '2023-09-22 21:39:24'),
(29, 'R.Sahithi Pallavi', 'Network applications', 'Python Network Programming is about using python as a programming language to handle computer networking requirement', 'Python', 'Networking', '2', 'logical', 'video', 'uploads/Python Network Programming _ Python Socket Programming _ Python Training _ Edureka.mp4', '2023-09-22 21:39:24'),
(30, 'R.Sahithi Pallavi', 'Web applications using frameworks', 'A Web framework is a collection of packages or modules which allow developers to write Web applications', 'Python', 'Web Development', '2', 'visual', 'video', 'uploads/Python Network Programming _ Python Socket Programming _ Python Training _ Edureka.mp4', '2023-09-22 21:39:24'),
(31, 'R.Sahithi Pallavi', 'Libraries like NumPy, pandas, and Matplotlib', 'The process of finding trends and correlations in our data by representing it pictorially', 'Python', 'Data Analysis and Visuali', '2', 'verbal', 'video', 'uploads/What Can You Do with Python_ - The 3 Main Applications.mp4', '2023-09-22 21:39:24'),
(32, 'V.Puneeth', 'Variables', 'Python variables are simply containers for storing data values. Unlike other languages, such as Java, Python has no command for declaring a variable, so you create one the moment you first assign a va', 'Python', 'Basic Python Syntax', '0', 'visual', 'video', 'uploads/#4 Python Tutorial for Beginners _ Variables in Python (1).mp4', '2023-09-22 21:41:05'),
(33, 'V.Puneeth', 'Data Types', 'In programming, data type is an important concept.\r\nVariables can store data of different types, and different types can do different things.\r\nPython has the following data types built-in by default, ', 'Python', 'Basic Python Syntax', '0', 'visual', 'video', 'uploads/#10 Python Tutorial for Beginners _ Data Types in Python.mp4', '2023-09-22 21:41:05'),
(34, 'V.Puneeth', 'Input And Output Operations', 'In Python, we use the print() function to output data to the screen. Sometimes we might want to take input from the user. We can do so by using the input() function. Python takes all the input as a st', 'Python', 'Basic Python Syntax', '0', 'logical', 'video', 'uploads/#18 Python Tutorial for Beginners _ User input in Python _ Command Line Input.mp4', '2023-09-22 21:41:05'),
(35, 'V.Puneeth', 'Conditional statements (if, elif, else)', 'They allow you to make decisions based on the values of variables or the result of comparisons', 'Python', ' Conditional  Strucures', '0', 'logical', 'video', 'uploads\\#4 Python Tutorial for Beginners _ Variables in Python (1).mp4', '2023-09-23 01:49:34'),
(36, 'V.Puneeth', 'Loops (for and while)', 'A loop is an instruction that repeats multiple times as long as some condition is met.', 'Python', 'Control Structure', '0', 'logical', 'video', 'uploads/#20 Python Tutorial for Beginners _ While Loop in Python.mp4', '2023-09-22 21:41:05'),
(37, 'Chitturi Karthik', 'HTML_Structuring a Mega Project', 'Building Robust Foundations! Explore advanced HTML organizing and structuring strategies for large-scale web projects.', 'Web Techno', 'HTML', '0', 'visual', 'video', 'uploads\\How to Create a Table in MySQL_ _ MySQL Tutorial for Beginners (2).mp4', '2023-09-23 01:51:49'),
(38, 'Chitturi Karthik', 'HTML Introduction', 'HTML stands for HyperText Markup Language.HTML is used to create web pages and web applications.HTML is widely used language on the web', 'Web Techno', 'HTML', '0', 'visual', 'video', 'uploads/HTML Course _ Worlds most premium HTML Course _ Lecture 2.mp4', '2023-09-22 21:42:41'),
(39, 'Chitturi Karthik', 'HTML Tags', 'HTML stands for HyperText Markup Language.HTML is used to create web pages and web applications.HTML is widely used language on the web', 'Web Techno', 'HTML', '0', 'visual', 'video', 'uploads/HTML Course _ From Beginners to Advance Level _ Lecture 1.mp4', '2023-09-22 21:42:41'),
(40, 'Chitturi Karthik', 'HTML Media Elements', 'HTML stands for HyperText Markup Language.HTML is used to create web pages and web applications. HTML is widely used language on the web', 'Web Techno', 'HTML ', '0', 'visual', 'video', 'uploads/HTML Course _ Media Elements _ Lecture 3.mp4', '2023-09-22 21:42:41'),
(41, 'Chitturi Karthik', 'CSS Introduction', 'CSS is the language we use to style an HTML document. CSS describes how HTML elements should be displayed. ', 'Web Techno', 'CSS', '0', 'logical', 'video', 'uploads/Understanding Cascading , Specificity and Inheritance _ CSS Lecture 4.mp4', '2023-09-22 21:34:50'),
(42, 'Phani Bhushan', 'hsadjk', 'gchvbm,.', 'C', 'chjvv', '0', 'logical', 'video', 'uploads/set1.mp4', '2023-09-23 03:33:32');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `id` int(10) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date_of_birth` varchar(25) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `learning_intelligence` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`id`, `student_name`, `email`, `date_of_birth`, `mobile`, `address`, `learning_intelligence`) VALUES
(1, 'Anuradha', 'anu.radhask@gmail.com', '5/14/2023', '7329864149', '485 plainfield rd', 'logical'),
(2, 'Ajay', 'apoondla@gmail.com', '3/29/2023', '1650759586', '2851 Biddleford Drive', 'verbal'),
(3, 'Kishore', 'aragorniiit@gmail.com', '4/25/2023', '7162088221', '635 Eldridge Dr', 'logical'),
(4, 'Seshagiri', 'asgiribabu@yahoo.com', '4/20/2023', '6099037728', '1 Thoreau Drive', 'existensial'),
(5, 'Venkata Ashok', 'Ashok.Myneni@gmail.com', '4/26/2023', '3024655446', '11065 callaway dr,', 'visual'),
(6, 'Balaji', 'balaji.raya@yahoo.com', '5/26/2023', '6098193982', '165 Mulberry Dr', 'existensial'),
(7, 'Bhanu', 'bhanukuppa@gmail.com', '04-01-2023', '8602050467', 'Avon', 'logical'),
(8, 'Bhanu', 'Bhanupd@hotmail.com', '03-12-2023', '8133624925', '10253 Estuary Dr', 'verbal'),
(9, 'Kalyan', 'bhumakalyan@gmail.com', '04-01-2023', '9526819946', '5075 Woodland ave', 'verbal'),
(10, 'Buddha', 'bkmuddana@yahoo.com', '3/27/2023', '4695349818', '1505 Bear Creek Dr', 'existensial'),
(11, 'Rajah', 'bkrajah@yahoo.com', '04-01-2023', '3367061270', '8017 HAZELTINE DR', 'existensial'),
(12, 'Bharath', 'boruganti@gmail.com', '3/27/2023', '2815200443', '901 Santaluz Path', 'verbal'),
(13, 'Vijaya Kumar', 'bvijay87@gmail.com', '3/25/2023', '124852534', '7944 N MacArthur Blvd', 'logical'),
(14, 'Krishna', 'chavak28@gmail.com', '04-08-2023', '7346348348', '18490 Clairmont Cir W', 'logical'),
(15, 'Srinivasa', 'chennu@hotmail.com', '04-02-2023', '5715441508', '44 Woodbridge Terrace #4D', 'verbal'),
(16, 'Naveenkumar', 'chnaveen@gmail.com', '4/22/2023', '8503393557', '2852 Lumber River Trail', 'visual'),
(17, 'Chandra', 'cnallam@encloudservices.com', '3/23/2023', '2482270139', '3 Bradish Lane', 'visual'),
(18, 'Sarat', 'dasaka@gmail.com', '4/19/2023', '4802392190', 'Dddkl', 'visual'),
(19, 'Tirumala', 'devi.ramamoorthy@gmail.com', '4/14/2023', '1678860154', '625 Fair View Cir', 'verbal'),
(20, 'Rambabu', 'devirambabu@gmail.com', '04-03-2023', '7814601225', '15 Davis rd', 'logical'),
(21, 'Diwakar', 'Diwakarwww@gmail.com', '04-03-2023', '9137489505', '7855 w 155th ter', 'verbal'),
(22, 'Durga Vikas', 'durgavikasthota@gmail.com', '04-10-2023', '7738483509', '4051 Enfield Ave', 'logical'),
(23, 'Venkata', 'dvsanr@gmail.com', '3/28/2023', '7546663336', '817 Champion Woods Ct', 'existensial'),
(24, 'Eswar', 'EELURI@REVASOLUTIONS.COM', '04-03-2023', '2066176426', '4249 Shoreclub Dr', 'visual'),
(25, 'Nagendra', 'endranag@gmail.com', '05-02-2023', '3126598100', '1598 California St', 'existensial'),
(26, 'Gokul', 'goksing@gmail.com', '5/27/2023', '6096477900', '8 anna lane', 'logical'),
(27, 'Gopi Krishna', 'gopi.tallapaneni@gmail.com', '5/18/2023', '7204017020', '11832 Skylark Rd', 'verbal'),
(28, 'Gopichand', 'gopi04@gmail.com', '3/19/2023', '8322652515', '10162 Christopher St', 'verbal'),
(29, 'Sharmila', 'guntaka.m.s@gmail.com', '4/17/2023', '8605684058', '15 Mason Cir', 'existensial'),
(30, 'Hariprasad', 'hariprasadduba@gmail.com', '3/23/2023', '6475253727', '4 Forest Laneway, Unit 804', 'existensial'),
(31, 'Harish', 'harish.rayapudi@gmail.com', '3/26/2023', '4085134041', '121 Fountayne Ln', 'verbal'),
(32, 'Haritha', 'haritha.pinninty@gmail.com', '5/22/2023', '6786707060', '1705 Rutland pkwy', 'logical'),
(33, 'N S S Kishore', 'hikishore@gmail.com', '04-09-2023', '140861359', '42640 Lemonwood St', 'logical'),
(34, 'Hari', 'hp1968@gmail.com', '3/25/2023', '2149986101', '4600 United Ln', 'verbal'),
(35, 'Hemanth', 'hyerneni@gmail.com', '3/22/2023', '3922904799', '1306 briggs way', 'visual'),
(36, 'Hyma', 'hymasworld@yahoo.com', '3/26/2023', '5084534722', '208 Sw 105th Ter', 'visual'),
(37, 'Jagannadh', 'jag.kanumuri@aciinfotech.com', '04-03-2023', '7324231139', '5 Gorman Ct', 'visual'),
(38, 'Raja Kumar', 'julapnet@gmail.com', '5/24/2023', '7324076474', '4 Aaron Ct', 'verbal'),
(39, 'Jaya Raghavendra Arun Kumar', 'jyellajo@mtu.edu', '3/31/2023', '8326520143', '12655 W Houston Center Blvd', 'logical'),
(40, 'Jyothi', 'jyothi.panchak@gmail.com', '4/15/2023', '2144185076', '1616 Earhart Ln', 'verbal'),
(41, 'Jyotsna', 'jyotsna.namburi@gmail.com', '04-03-2023', '2482295401', '28 Pine Hill Ln', 'logical'),
(42, 'Koteswara', 'j_vepuri@yahoo.com', '5/21/2023', '7142778524', '5840 Bradford ct', 'existensial'),
(43, 'Kalyan', 'kalyan.sirivella@gmail.com', '04-05-2023', '19197494', '714 Willow Ridge Ct', 'visual'),
(44, 'Kalyani', 'kalyaniyellapu@yahoo.com', '4/20/2023', '7039676255', '10450 Artemel Lane', 'existensial'),
(45, 'RAVI', 'kandarpar@yahoo.com', '4/30/2023', '2148688586', '503 PATAGONIAN PL', 'logical'),
(46, 'Kanthisri', 'kanthisri@gmail.com', '03-12-2023', '7325868765', '62 primrose circle', 'verbal'),
(47, 'Karthik Ch', 'karthikch.official@gmail.com', '22-08-2003', '9398954816', 'Kothapet , Palakol , 534260 , AndhraPradesh', 'verbal'),
(48, 'Balamurali', 'kbalamurali@yahoo.com', '04-04-2023', '4802627340', '672 W Alamosa Dr', 'existensial'),
(49, 'Kiran', 'kiranvadlani@gmail.com', '04-02-2023', '6032335397', '54 Vincent behan blvd', 'existensial'),
(50, 'Kishore', 'kish_k@yahoo.com', '04-01-2023', '7149320155', '4332 Pepperdine Pl', 'verbal'),
(51, 'Krishna', 'kkancherla@yahoo.com', '4/15/2023', '8454539878', '32 Kimlin Ct', 'logical'),
(52, 'Kousalya', 'kous.chukkapalli@gmail.com', '04-07-2023', '4084319569', '3294 Ruffino Ln', 'logical'),
(53, 'Krishna', 'krishna.m.manda@gmail.com', '3/27/2023', '2145423624', '9854 Deerfield Dr', 'verbal'),
(54, 'Krishna', 'krishnadandamudi@yahoo.com', '3/31/2023', '9729797272', '3120 San Simeon Way', 'visual'),
(55, 'Krishna kumar', 'krishnakbeta@yahoo.com', '4/15/2023', '9493573729', '41 Cabrillo Ter', 'visual'),
(56, 'Krishna', 'krrish.iitm.ac.in@gmail.com', '05-01-2023', '8328071655', '2827 Dunvale Road', 'visual'),
(57, 'Sambasivarao', 'ksambasiva@gmail.com', '4/16/2023', '7329107562', '10619 Dabney Dr', 'verbal'),
(58, 'Suresh', 'kumarbu@gmail.com', '4/15/2023', '173257028', '52 Vincent Behan Blvd', 'logical'),
(59, 'Sreekiran', 'k_vallurupalli@redsalsa.com', '04-03-2023', '7326486944', '102 Hanson Rd', 'verbal'),
(60, 'Lalitha', 'lalithake@gmail.com', '04-07-2023', '7038619872', '1000 evonshire ln', 'logical'),
(61, 'Lakshmanjee', 'lkolli2006@gmail.com', '3/20/2023', '8479466938', '7191 Pennsbury Lane', 'existensial'),
(62, 'Lalitha', 'lsangana@gmail.com', '4/19/2023', '5124616122', '11200 Savin hill lane', 'visual'),
(63, 'Someswara Swamy', 'madhira.swamy@gmail.com', '3/14/2023', '4085057423', '5574 GREELEY PLACE', 'existensial'),
(64, 'Madhu', 'madhu.tera@gmail.com', '5/23/2023', '7816403140', '85 Canterbury Hill Rd', 'logical'),
(65, 'Madhuri', 'MadhuriMokarala@gmail.com', '4/16/2023', '7322599452', '174 pleasant run road', 'verbal'),
(66, 'Sudhakar', 'mandalikasudhakar@gmail.com', '3/18/2023', '4167263495', '1485 Birchmount Rd.', 'verbal'),
(67, 'Manjula', 'manjulavm@gmail.com', '04-09-2023', '6362228319', '264 magnolia trace dr', 'existensial'),
(68, 'Pratima', 'mantena.pratima@gmail.com', '04-05-2023', '4106033141', '7 REDWOOD PATH', 'existensial'),
(69, 'Sruthima', 'mantenasruthi892@gmail.com', '3/29/2023', '2707995252', '27 Galligen Dr', 'verbal'),
(70, 'Mitra', 'mitra.kaseebhotla@gmail.com', '3/18/2023', '6508685190', '2844 Westwood Ave', 'logical'),
(71, 'Mohan', 'mkneelam@gmail.com', '05-12-2023', '2814519665', '4006 Sutton Shadow Ln', 'logical'),
(72, 'Gita Madhavi', 'mmadhavi1022@gmail.com', '04-01-2023', '4087726046', '1022 Applewood dr', 'verbal'),
(73, 'Satish', 'msbrams@gmail.com', '3/22/2023', '6478048450', '625 Hyacinthe Blvd', 'visual'),
(74, 'Ravi', 'mukthineni@gmail.com', '05-08-2023', '6177926295', '4 Triphammer Rd', 'visual'),
(75, 'Nagamani', 'nagamani.immaneni@gmail.com', '5/23/2023', '8566568067', '2101,Greenwood dr', 'visual'),
(76, 'ANJANEYULU', 'nalabothu1@yahoo.com', '05-01-2023', '7323064962', '25 CINDER ROAD, 2K', 'verbal'),
(77, 'Nandini', 'nandumaguluru@gmail.com', '4/22/2023', '7143073748', '717 Johns ave', 'logical'),
(78, 'Sita', 'naralasetty@gmail.com', '04-04-2023', '4088365342', '1111 weyburn ln', 'verbal'),
(79, 'sravanalaya', 'naralasettylaya@gmail.com', '5/13/2023', '5715308094', '14 marsh ct', 'logical'),
(80, 'Narasa Raju', 'narasaraju.penmetsa@gmail.com', '05-03-2023', '2102183912', '1835 Fox Prairie Rd', 'existensial'),
(81, 'Naresh', 'nareshapril8@gmail.com', '04-04-2023', '4088988461', '43555 Grimmer Blvd', 'visual'),
(82, 'Naresh', 'nchimakurty@gmail.com', '3/20/2023', '5714380086', '1151 Phallen Ct NW', 'existensial'),
(83, 'Neelima', 'nimmy5@yahoo.com', '4/16/2023', '2562890018', '6823 Entelman Ln', 'logical'),
(84, 'Satish', 'nsatishbabu@gmail.com', '05-08-2023', '4089304057', '4329 Healdsburg way', 'verbal'),
(85, 'Pavani', 'parupudip@hotmail.com', '03-12-2023', '2812532558', '3810 Nottingham Bluff Ln', 'verbal'),
(86, 'Srinivas', 'parupudi_s@hotmail.com', '3/28/2023', '2812530085', '3810 Nottingham Bluff Ln', 'existensial'),
(87, 'Pattabhi', 'pattabhiy@yahoo.com', '04-01-2023', '2482452465', '6373 Charles Sr', 'existensial'),
(88, 'Krishna', 'pendurthi.krishna@gmail.com', '05-07-2023', '19734091', '2719 Derby Dr', 'verbal'),
(89, 'Raju', 'penematcha@gmail.com', '3/28/2023', '7326193164', '3 Angelica ct', 'logical'),
(90, 'Phalgun', 'phalgunry@gmail.com', '3/19/2023', '7042904871', '704 Copper Tree Ln', 'logical'),
(91, 'Phani Bhushan', 'phanibhushanj@gmail.com', '3/28/2023', '2055423338', '1518, Riverchase Trl', 'verbal'),
(92, 'Pradeep', 'pksomava@yahoo.com', '4/16/2023', '4025177283', '3218 N 168th Ave', 'visual'),
(93, 'Prabhakar', 'prab@stridegp.com', '5/18/2023', '2146685992', '910 Edgemeer lane', 'visual'),
(94, 'Prasad', 'prasad.gunturi@gmail.com', '4/14/2023', '19526861', '9776 Cupola Ln', 'visual'),
(95, 'Subbarao', 'punnamaraju@gmail.com', '3/26/2023', '6175951173', '6 Turning Leaf Cir', 'verbal'),
(96, 'VVA Siva Kumar', 'puvvala.siva@gmail.com', '04-02-2023', '2035545907', '35 Diamondback Ave', 'logical'),
(97, 'Satish', 'pvsssraju@gmail.com', '04-05-2023', '4106038136', '7 REDWOOD PATH', 'verbal'),
(98, 'Prasada', 'pylainfo@gmail.com', '4/23/2023', '2018509668', '1 Balzano Ct', 'logical'),
(99, 'Manjula', 'p_manjula@hotmail.com', '04-01-2023', '5104566599', '34304 Marjoram loop', 'existensial'),
(100, 'Satya', 'raavisn@hotmail.com', '3/19/2023', '2145648032', '8109 Sutherland ln', 'visual'),
(101, 'Raghu', 'raghuvadlamudi@comcast.net', '4/19/2023', '6512614685', '727 Lake Ridge Drive', 'existensial'),
(102, 'Rajan', 'rajanbeera@prodigy.net', '4/26/2023', '8173689908', '162 Gadwall Ln', 'logical'),
(103, 'Rajendra', 'Rajendra.Kottakota@gmail.com', '3/21/2023', '9788061764', '173 Range Rd', 'verbal'),
(104, 'venkata rajesh', 'rajesh2008ad@gmail.com', '04-01-2023', '190628189', '4980 usaa blvd', 'verbal'),
(105, 'Rajesh', 'rajeshhariyala@gmail.com', '5/24/2023', '7323972191', '8 Creemer Ave', 'existensial'),
(106, 'Rajagopal', 'rajgopal.paladugu@gmail.com', '3/25/2023', '5184913662', '6333 Oceanview Dr', 'existensial'),
(107, 'Subbaraju', 'rajurkakrlapudi@gmail.com', '3/19/2023', '7148696117', '2012 Tweed St', 'verbal'),
(108, 'Swamy Rakesh', 'rakhi.rakesh@gmail.com', '3/20/2023', '4087978595', '2336 Campus Club Ct', 'logical'),
(109, 'Ramakrishna', 'ramakrishna.kandula@gmail.com', '3/20/2023', '4089049990', 'Cupertino', 'logical'),
(110, 'Ramesh', 'ramesh.koduri@gmail.com', '4/26/2023', '4439330017', '4013 Red Stag Ct', 'verbal'),
(111, 'Ramesh', 'Ramesh.Kothamasu@gmail.com', '3/19/2023', '3024382378', '206 COOLIDGE LN', 'visual'),
(112, 'Ramakrishna', 'ramki.palle@gmail.com', '04-02-2023', '4085373913', '7173 9th Hole Dr', 'visual'),
(113, 'Venkata', 'raovtalluri@gmail.com', '05-02-2023', '8436421370', '5000 Aspen Pine Blvd, Dublin', 'visual'),
(114, 'Ravikumar', 'ravikumar.karra@gmail.com', '3/27/2023', '1919600122', '1020 Pondfield Way', 'verbal'),
(115, 'Ravindra', 'ravindra.kakara@gmail.com', '3/26/2023', '5109848015', '2538 Imperial Valley Trl', 'logical'),
(116, 'Ravi Sankar', 'raviska2308@gmail.com', '4/25/2023', '8567938563', '1322 E Gemini Pl', 'verbal'),
(117, 'Venkata Ravi Varma', 'ravivarma.gv@gmail.com', '3/28/2023', '4242473874', '14137 Steadman Dr', 'logical'),
(118, 'Ravi', 'ravivarma@gmail.com', '3/22/2023', '2157158950', '2492 quick st', 'existensial'),
(119, 'Ravi', 'raviveer@yahoo.com', '03-12-2023', '1630337721', '2519 James Monroe Circle', 'visual'),
(120, 'Kiran', 'ray@cabsinc.com', '4/19/2023', '7325434865', '40 Devonshire Dr', 'existensial'),
(121, 'Ravi', 'rbanda68@gmail.com', '3/14/2023', '7037867894', '5607 Hemingway Lane', 'logical'),
(122, 'Ravindra', 'rchalla999@gmail.com', '3/29/2023', '8322078079', '5501 Marina DR', 'verbal'),
(123, 'Raju', 'rdatla007@gmail.com', '3/31/2023', '7325168438', '2 Amy Court', 'verbal'),
(124, 'DEVI PADMINI PRIYANKA', 'RDPPRIYANKA@GMAIL.COM', '3/31/2023', '123651593', '12993 101A Ave', 'existensial'),
(125, 'Rao', 'RKONIJETI@YAHOO.COM', '3/22/2023', '4023128836', '11162 MANUEL ST', 'existensial'),
(126, 'Rammohan', 'rmeshineni@gmail.com', '3/25/2023', '8328480289', '7602 Westmoreland Dr', 'verbal'),
(127, 'Murali', 'rmk_raju@yahoo.com', '4/14/2023', '4087997555', '3371 Tracy Dr', 'logical'),
(128, 'Hanumanth', 'rphanu@gmail.com', '3/29/2023', '8584316975', '12849 Starwood Ln, San Diego, CA 92131, USA', 'logical'),
(129, 'Praveen', 'rpravi@gmail.com', '4/30/2023', '3135103155', '191 Blue heron dr', 'verbal'),
(130, 'Ravi', 'rpvarre@hotmail.com', '3/22/2023', '8324193745', '10619 Pebblecreek Xing', 'visual'),
(131, 'ravi', 'rshankars@gmail.com', '3/21/2023', '6504545547', '4720 Creekwood dr', 'visual'),
(132, 'Saicharan', 'saicharan.vaddadi@gmail.com', '4/21/2023', '166052809', '11804 ETON MANOR DR', 'visual'),
(133, 'Sailaja', 'sailajamudunuri@gmail.com', '3/26/2023', '9194911035', '921 river song pl', 'verbal'),
(134, 'Sangeetha', 'sangeethasatya@gmail.com', '3/27/2023', '9196078040', '270 Oak Haven Ln', 'logical'),
(135, 'Santhi', 'santhi.sonthi2009@gmail.com', '5/21/2023', '9788538969', '679 Windermere Way', 'verbal'),
(136, 'Sarath', 'sarath_kalidindi@yahoo.com', '4/22/2023', '7323061849', '20 York Road', 'logical'),
(137, 'Sakuntala', 'sashi.sagiraju@gmail.com', '04-02-2023', '4694280733', '13561 Bigelow Ln', 'existensial'),
(138, 'Satish', 'satish.mantena@gmail.com', '4/21/2023', '173270503', '17 Hartlander St', 'visual'),
(139, 'Satish', 'satishv9@gmail.com', '5/26/2023', '8482023159', '2490 Quick Street', 'existensial'),
(140, 'Sattar', 'sattarshaik70@gmail.com', '04-01-2023', '7035877688', '19971 BELMONT STATION DR', 'logical'),
(141, 'Satyam', 'satyam.appadwedula@gmail.com', '3/30/2023', '4149152256', 'W194N5691 Deer Park ct', 'verbal'),
(142, 'Srinivasa', 'sbkunamneni@gmail.com', '3/14/2023', '7032582279', '20348 Medalist Drive', 'verbal'),
(143, 'Sainadh', 'schekuri@yahoo.com', '4/18/2023', '6093564657', '115 Kickapoo Drive', 'existensial'),
(144, 'sudhir', 'schepeni@gmail.com', '3/20/2023', '9087311307', '4 HILL ST', 'existensial'),
(145, 'Suman', 'schepuri@yahoo.com', '3/25/2023', '9726894234', '7257 Waters Edge Dr', 'verbal'),
(146, 'Srinivas', 'serukull@gmail.com', '3/27/2023', '5124157058', '4018 Lazy River Bnd', 'logical'),
(147, 'Srinivasa', 'sgowru@hotmail.com', '04-04-2023', '4088355769', '12705 Monterey Path', 'logical'),
(148, 'Shashidhar', 'shashikura@yahoo.com', '4/29/2023', '5089042452', '30 Arch St', 'verbal'),
(149, 'Shyam', 'shyamvaddadi@gmail.com', '5/22/2023', '7178563599', '472 Barbara Dr.', 'visual'),
(150, 'Suresh', 'skvoona@yahoo.com', '5/24/2023', '9173314695', '41 Woodmere rd', 'visual'),
(151, 'Sridhar', 'sridharpattisapu@gmail.com', '5/22/2023', '8456990483', '404 Old Tappan Rd', 'visual'),
(152, 'Sri Ravi Sankar', 'srigangavarapu@gmail.com', '04-09-2023', '8626864120', '1 Bennington Dr', 'verbal'),
(153, 'Srihari', 'sriharikolli@yahoo.com', '4/24/2023', '6149375564', '19208 Autumn Woods Ave', 'logical'),
(154, 'Srikanth', 'srikanth.kottakota@gmail.com', '04-04-2023', '8182093776', '1711 GRISMER AVE #84', 'verbal'),
(155, 'Srikiran', 'srikiranp@gmail.com', '5/16/2023', '9192448050', '485 plainfield rd', 'logical'),
(156, 'Srilakshmi', 'Srilakshmi.nit@gmail.com', '05-08-2023', '1682304513', '3589 empire dr', 'existensial'),
(157, 'Srinivasa Rao', 'srinibell@gmail.com', '04-01-2023', '4088937656', '1225 SURVADA LN', 'visual'),
(158, 'Srini', 'sriniSaranu@gmail.com', '04-08-2023', '5714275365', '21302 southolme way', 'existensial'),
(159, 'Srinivasa', 'srinivasa.gollapudi@gmail.com', '5/25/2023', '8482197761', '147 whitehead ave', 'logical'),
(160, 'Srujana', 'srujanakoripalli@gmail.com', '3/23/2023', '6692261644', '4325 Renaissance Dr', 'verbal'),
(161, 'Sruthima', 'sruthi7755@gmail.com', '4/19/2023', '2707995251', '27 Galligen Dr', 'verbal'),
(162, 'Srinivas', 'sshkota@gmail.com', '4/14/2023', '140888612', '1971 H Street', 'existensial'),
(163, 'Srinivas', 'ssunkara@hotmail.com', '04-09-2023', '5719199265', '44413 Stone Roses Cir', 'existensial'),
(164, 'Subbarao', 'subba.suda@gmail.com', '5/18/2023', '5122967102', '235 Cutleaf Cir', 'verbal'),
(165, 'Sudharani', 'sudhamarupudi@gmail.com', '3/27/2023', '1703350538', '20080 BLACKWOLF RUN PL', 'logical'),
(166, 'Sudheer', 'sudheersura@yahoo.com', '5/20/2023', '2817251087', '28010 Indigo Ridge Dr', 'logical'),
(167, 'Suneetha', 'sumudunu@gmail.com', '04-02-2023', '6179388714', 'Sammamish', 'verbal'),
(168, 'Suren Kumar', 'surenrvl@gmail.com', '3/28/2023', '2012201021', '3507 Snow Chief Road', 'visual'),
(169, 'Surendra', 's_surendra@hotmail.com', '5/23/2023', '7327425268', '203 Wellington Park Drive', 'visual'),
(170, 'Sirisha', 'tata_sirisha@hotmail.com', '3/20/2023', '9145140007', '920 Howard Ave', 'visual'),
(171, 'Anuradha', 'uanuradha@gmail.com', '5/21/2023', '9789851404', '24 Hartwell Brook', 'verbal'),
(172, 'Durga vara prasad', 'ucontactraju@gmail.com', '4/19/2023', '7324286912', '225 harbor hills dr', 'logical'),
(173, 'Uday', 'udaykarrothi@gmail.com', '3/29/2023', '4089101276', '4622 Avery Ct', 'verbal'),
(174, 'Ramakrishnam', 'urskrkraju@gmail.com', '04-02-2023', '6502431897', '2517 Avenue N', 'logical'),
(175, 'Dilip', 'vadlamudidilip@gmail.com', '04-01-2023', '3176701124', '5467 N Grandin Hall Cir', 'existensial'),
(176, 'Vamsi Krishna', 'vamsi.chekuri@gmail.com', '4/19/2023', '3022295867', '3125 Mclaughlin Ct', 'visual'),
(177, 'Surya Vandana', 'vandanaveluri@gmail.com', '04-12-2023', '7034341394', '13104 Queensdale Dr.', 'existensial'),
(178, 'Sreevani', 'vani318@yahoo.com', '04-07-2023', '7037327034', '1902 Dalmation Drive', 'logical'),
(179, 'Varma', 'varmak3939@yahoo.com', '3/19/2023', '9259150193', '5072 VOLTERRA COURT', 'verbal'),
(180, 'Vasavi', 'vasavi_gupta@yahoo.com', '04-01-2023', '9196013556', '1304 Bravura Drive', 'verbal'),
(181, 'Praveena', 'veenapra@gmail.com', '3/14/2023', '7788698362', '11115 upper canyon road', 'existensial'),
(182, 'Raghu', 'vemuri.raghu@gmail.com', '5/18/2023', '1408513559', '2913 Delamar Dr.', 'existensial'),
(183, 'Venkat', 'venkat.chivukula@gmail.com', '05-11-2023', '9257504342', '2285 Brandini Dr', 'verbal'),
(184, 'Venkatesh', 'venkatesh.duggirala@gmail.com', '4/13/2023', '5103868895', '4216 WAYCROSS COURT', 'logical'),
(185, 'Venkat Raju', 'venkatraju1987@gmail.com', '5/26/2023', '4258294172', '12929 Centrepark Cir', 'logical'),
(186, 'Venu', 'venu@cepoch.com', '3/25/2023', '8476440564', '24 Rainier Cir', 'verbal'),
(187, 'Venkateswara', 'vgadde@gmail.com', '3/13/2023', '7706241214', '2645 Copperfield Dr', 'visual'),
(188, 'Vijaya', 'vij.kosuri@gmail.com', '04-02-2023', '4043131150', '5630 Warmstone Ln , Suwanee, GA 30024', 'visual'),
(189, 'Vijay', 'vijayrr007@gmail.com', '4/27/2023', '7147329472', '24626 Edmond ridge place', 'visual'),
(190, 'Sesha Bhavani', 'vijji.soma@gmail.com', '3/31/2023', '4256473351', '4104 220th St SE', 'verbal'),
(191, 'Venkata Sudhakar', 'vkalikay@gmail.com', '04-02-2023', '4088365506', '1301 Bray Central', 'logical'),
(192, 'VIJAYAKUMAR', 'vkveeragandham@gmail.com', '5/24/2023', '6052140519', '1 APRIL LN', 'verbal'),
(193, 'Suresh', 'vobbilis@gmail.com', '3/28/2023', '4082741124', '3607 Rue Mirassou', 'logical'),
(194, 'SuryaPrakash', 'volety2@gmail.com', '4/25/2023', '150877691', '13069 Avanti dr', 'existensial'),
(195, 'Vani', 'vsurangi@gmail.com', '3/27/2023', '9094995499', '221 Radial', 'visual'),
(196, 'Suresh', 'vsureshbabu20@gmail.com', '4/15/2023', '9548714448', '11836 W Sample Rd', 'existensial'),
(197, 'Prabhu', 'vtprabhukumar@yahoo.co.in', '4/26/2023', '2165040909', '1553 Crestwood Road', 'logical'),
(198, 'Venkata', 'VvenkatReddy@gmail.com', '4/19/2023', '6785767696', '62 Loft Dr', 'verbal'),
(199, 'Ramakrishna', 'yarkar@gmail.com', '04-10-2023', '6307247810', '921 Panorama Dr', 'verbal'),
(200, 'Venkatakrishna', 'yenduri.venkat@gmail.com', '5/21/2023', '7326291020', '172 windsong circle', 'existensial');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` varchar(10) NOT NULL,
  `subject_name` varchar(25) NOT NULL,
  `teacher_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES
('S1', 'C Language', 'c1'),
('S2', 'Web Technologies', 'w1'),
('S3', 'Python', 'p1');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_details`
--

CREATE TABLE `teacher_details` (
  `id` int(5) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date_of_birth` varchar(20) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `current_role` varchar(25) NOT NULL,
  `working at` varchar(50) NOT NULL,
  `img_path` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher_details`
--

INSERT INTO `teacher_details` (`id`, `teacher_name`, `email`, `date_of_birth`, `mobile`, `address`, `current_role`, `working at`, `img_path`) VALUES
(1, 'Phani Bhushan', 'phanibhushanj@gmail.com', '3/28/2023', '2055423338', '1518, Riverchase Trl', '', 'AVP', 'Cognizant'),
(2, 'Balamurali', 'kbalamurali@yahoo.com', '4/4/2023', '4802627340', '672 W Alamosa Dr', '', 'Senior Information Security Engineer', 'HD Supply Inc'),
(3, 'Ravi Sankar', 'raviska2308@gmail.com', '4/25/2023', '8567938563', '1322 E Gemini Pl', '', '', ''),
(4, 'Praveena', 'veenapra@gmail.com', '3/14/2023', '7788698362', '11115 upper canyon road', '', 'ECM Applications Analyst', 'City of Surrey'),
(5, 'DEVI PADMINI PRIYANKA', 'RDPPRIYANKA@GMAIL.COM', '3/31/2023', '+123651593', '12993 101A Ave', '', '', 'Bank of America '),
(6, 'Someswara Swamy', 'madhira.swamy@gmail.com', '3/14/2023', '4085057423', '5574 GREELEY PLACE', '', '', 'Nokia Inc'),
(7, 'Mitra', 'mitra.kaseebhotla@gmail.com', '3/18/2023', '6508685190', '2844 Westwood Ave', '', 'Sr. Engineering Manager ', 'HPE'),
(8, 'Varma', 'varmak3939@yahoo.com', '3/19/2023', '9259150193', '5072 VOLTERRA COURT', 'logical', 'IT Consultant/Co-Founder', 'Serenity Info Tech, Inc'),
(9, 'Subbaraju', 'rajurkakrlapudi@gmail.com', '3/19/2023', '7148696117', '2012 Tweed St', 'visual', 'DBA', 'LACounty - Department of Economic Opportunity '),
(10, 'Gopichand', 'gopi04@gmail.com', '3/19/2023', '8322652515', '10162 Christopher St', 'verbal', '', ''),
(11, 'Ramakrishna', 'ramakrishna.kandula@gmail.com', '3/20/2023', '4089049990', 'Cupertino', 'logical', 'CTO AccuQuote,Inc.', 'Swiss Re'),
(12, 'ravi', 'rshankars@gmail.com', '3/21/2023', '6504545547', '4720 Creekwood dr', 'visual', 'Staff Scientist', 'College of Public Health, University of South Florida'),
(13, 'Srujana', 'srujanakoripalli@gmail.com', '3/23/2023', '6692261644', '4325 Renaissance Dr', 'verbal', 'DevOps Manager', 'Finastra'),
(14, 'Vani', 'vsurangi@gmail.com', '3/27/2023', '9094995499', '221 Radial', 'logical', 'Sr. Staff Software Engineer ', 'Charles Schwab'),
(15, 'Suresh', 'vobbilis@gmail.com', '3/28/2023', '4082741124', '3607 Rue Mirassou', 'visual', '', 'PTC Therapeutics'),
(16, 'Ajay', 'apoondla@gmail.com', '3/29/2023', '1650759586', '2851 Biddleford Drive', 'verbal', 'Vice President', 'Citi bank'),
(17, 'Uday', 'udaykarrothi@gmail.com', '3/29/2023', '4089101276', '4622 Avery Ct', 'logical', 'Associate Director, IT', 'Jazz Pharma'),
(18, 'Hanumanth', 'rphanu@gmail.com', '3/29/2023', '8584316975', '12849 Starwood Ln, San Diego, CA 92131, USA', 'visual', 'Integration Specialist ', ''),
(19, 'Gita Madhavi', 'mmadhavi1022@gmail.com', '4/1/2023', '4087726046', '1022 Applewood dr', 'verbal', 'Tech Lead', 'The Hartford Financial Group'),
(20, 'Manjula', 'p_manjula@hotmail.com', '4/1/2023', '5104566599', '34304 Marjoram loop', 'logical', 'Sr. Director Market Lead', 'ITCINFOTECH inc.  '),
(21, 'Kishore', 'kish_k@yahoo.com', '4/1/2023', '7149320155', '4332 Pepperdine Pl', 'visual', '', ''),
(22, 'Kalyan', 'bhumakalyan@gmail.com', '4/1/2023', '9526819946', '5075 Woodland ave', 'verbal', 'Research Engineer', 'Southwest research institute'),
(23, 'Srikanth', 'srikanth.kottakota@gmail.com', '4/4/2023', '8182093776', '1711 GRISMER AVE #84', 'logical', 'Founder/CEO', 'Reva Solutions'),
(24, 'Naresh', 'nareshapril8@gmail.com', '4/4/2023', '4088988461', '43555 Grimmer Blvd', 'visual', 'Performance Manager', 'Emerson'),
(25, 'Sita', 'naralasetty@gmail.com', '4/4/2023', '4088365342', '1111 weyburn ln', 'verbal', 'Technology support specialist Graduate assistant ', 'GA and Master of information systems student '),
(26, 'Kousalya', 'kous.chukkapalli@gmail.com', '4/7/2023', '4084319569', '3294 Ruffino Ln', 'logical', 'Integration Architect', 'Sage IT Inc'),
(27, 'N S S Kishore', 'hikishore@gmail.com', '4/9/2023', '+140861359', '42640 Lemonwood St', 'visual', 'Principal', 'Anitya'),
(28, 'Venkatesh', 'venkatesh.duggirala@gmail.com', '4/13/2023', '5103868895', '4216 WAYCROSS COURT', 'verbal', 'Sr Manager', 'JP Morgan'),
(29, 'Srinivas', 'sshkota@gmail.com', '4/14/2023', '+140888612', '1971 H Street', 'logical', 'Sr Software Engg', 'Google'),
(30, 'Murali', 'rmk_raju@yahoo.com', '4/14/2023', '4087997555', '3371 Tracy Dr', 'visual', 'Principal Software Engineer', 'ZScaler Inc '),
(31, 'Krishna kumar', 'krishnakbeta@yahoo.com', '4/15/2023', '9493573729', '41 Cabrillo Ter', 'verbal', '', ''),
(32, 'Sambasivarao', 'ksambasiva@gmail.com', '4/16/2023', '7329107562', '10619 Dabney Dr', 'logical', 'Oracle Application Consultant ', 'Automus Consulting '),
(33, 'Sarat', 'dasaka@gmail.com', '4/19/2023', '4802392190', 'Dddkl', 'visual', '', 'Austin Community College '),
(34, 'Krishna', 'pendurthi.krishna@gmail.com', '5/7/2023', '0019734091', '2719 Derby Dr', 'verbal', '', 'Honda R&D '),
(35, 'Satish', 'nsatishbabu@gmail.com', '5/8/2023', '4089304057', '4329 Healdsburg way', 'logical', '', ''),
(36, 'Venkat', 'venkat.chivukula@gmail.com', '5/11/2023', '9257504342', '2285 Brandini Dr', 'visual', 'Principal Engineer', 'IP Infusion Inc'),
(37, 'Raghu', 'vemuri.raghu@gmail.com', '5/18/2023', '1408513559', '2913 Delamar Dr.', 'verbal', '', ''),
(38, 'Bhanu', 'bhanukuppa@gmail.com', '4/1/2023', '8602050467', 'Avon', 'logical', 'Director', 'ENGIN-IC'),
(39, 'Sharmila', 'guntaka.m.s@gmail.com', '4/17/2023', '8605684058', '15 Mason Cir', 'visual', '', ''),
(40, 'Bhanu', 'Bhanupd@hotmail.com', '3/12/2023', '8133624925', '10253 Estuary Dr', 'verbal', 'SAP GRC/Security Architect', 'Lockheed Martin'),
(41, 'Swamy Rakesh', 'rakhi.rakesh@gmail.com', '3/20/2023', '4087978595', '2336 Campus Club Ct', 'logical', 'IT Lead', 'Astellas'),
(42, 'Bhanu', 'Bhanupd@hotmail.com', '3/25/2023', '8133624925', '10253 Estuary Dr', 'visual', 'Content Distribution Systems Expert', 'Apple Inc'),
(43, 'Venkata', 'dvsanr@gmail.com', '3/28/2023', '7546663336', '817 Champion Woods Ct', 'verbal', '', 'CGI'),
(44, 'Suresh', 'vsureshbabu20@gmail.com', '4/15/2023', '9548714448', '11836 W Sample Rd', 'logical', 'IT Support', 'Independent Consultant'),
(45, 'Srihari', 'sriharikolli@yahoo.com', '4/24/2023', '6149375564', '19208 Autumn Woods Ave', 'visual', '', ''),
(46, 'Santhi', 'santhi.sonthi2009@gmail.com', '5/21/2023', '9788538969', '679 Windermere Way', 'verbal', 'Sr Oracle Dba', 'Adp'),
(47, 'Venkateswara', 'vgadde@gmail.com', '3/13/2023', '7706241214', '2645 Copperfield Dr', 'logical', 'Director of Engineering', 'E-Ring, Inc.'),
(48, 'Vijaya', 'vij.kosuri@gmail.com', '4/2/2023', '4043131150', '5630 Warmstone Ln , Suwanee, GA 30024', 'visual', '', 'ADP'),
(49, 'Tirumala', 'devi.ramamoorthy@gmail.com', '4/14/2023', '1678860154', '625 Fair View Cir', 'verbal', 'Executive Vice President ', 'Gallagher Re'),
(50, 'Kishore', 'aragorniiit@gmail.com', '4/25/2023', '7162088221', '635 Eldridge Dr', 'logical', '', 'Verizon'),
(51, 'Venkata Ashok', 'Ashok.Myneni@gmail.com', '4/26/2023', '3024655446', '11065 callaway dr,', 'visual', 'Chief Technology Officer', 'Pall Corporation'),
(52, 'Haritha', 'haritha.pinninty@gmail.com', '5/22/2023', '6786707060', '1705 Rutland pkwy', 'verbal', '', ''),
(53, 'Lakshmanjee', 'lkolli2006@gmail.com', '3/20/2023', '8479466938', '7191 Pennsbury Lane', 'logical', '', 'Self employed/ Cloud Decisions and Real Estate/ Zovest Capital'),
(54, 'Venu', 'venu@cepoch.com', '3/25/2023', '8476440564', '24 Rainier Cir', 'visual', 'Director, IT Enterprise Services', 'HF Sinclair Corporation'),
(55, 'Ravindra', 'ravindra.kakara@gmail.com', '3/26/2023', '5109848015', '2538 Imperial Valley Trl', 'verbal', '', ''),
(56, 'Durga Vikas', 'durgavikasthota@gmail.com', '4/10/2023', '7738483509', '4051 Enfield Ave', 'logical', '', ''),
(57, 'Nagendra', 'endranag@gmail.com', '5/2/2023', '3126598100', '1598 California St', 'visual', '', ''),
(58, 'Dilip', 'vadlamudidilip@gmail.com', '4/1/2023', '3176701124', '5467 N Grandin Hall Cir', 'verbal', '', ''),
(59, 'Diwakar', 'Diwakarwww@gmail.com', '4/3/2023', '9137489505', '7855 w 155th ter', 'logical', 'President & CEO', 'Red Salsa Technologies, Inc.'),
(60, 'Suren Kumar', 'surenrvl@gmail.com', '3/28/2023', '2012201021', '3507 Snow Chief Road', 'visual', 'CEO & Managing Director - Tekpulse Technologies LL', 'Tekpulse Technologies LLC. and Cognizant Technology Services'),
(61, 'Saicharan', 'saicharan.vaddadi@gmail.com', '4/21/2023', '+166052809', '11804 ETON MANOR DR', 'verbal', '', ''),
(62, 'Ramesh', 'ramesh.koduri@gmail.com', '4/26/2023', '4439330017', '4013 Red Stag Ct', 'logical', 'Principal Architect', 'Altera Digital Health'),
(63, 'Gopi Krishna', 'gopi.tallapaneni@gmail.com', '5/18/2023', '7204017020', '11832 Skylark Rd', '', 'Managing Partner', 'Stride Growth Partners '),
(64, 'Kanthisri', 'kanthisri@gmail.com', '3/12/2023', '7325868765', '62 primrose circle', '', 'Scrum Expert ', 'MassMutal '),
(65, 'sudhir', 'schepeni@gmail.com', '3/20/2023', '9087311307', '4 HILL ST', '', '', ''),
(66, 'Chandra', 'cnallam@encloudservices.com', '3/23/2023', '2482270139', '3 Bradish Lane', '', '', ''),
(67, 'Subbarao', 'punnamaraju@gmail.com', '3/26/2023', '6175951173', '6 Turning Leaf Cir', '', '', ''),
(68, 'Rambabu', 'devirambabu@gmail.com', '4/3/2023', '7814601225', '15 Davis rd', '', '', ''),
(69, 'Sreekiran', 'k_vallurupalli@redsalsa.com', '4/3/2023', '7326486944', '102 Hanson Rd', '', 'Sr Data Engineer ', 'CrowdStrike'),
(70, 'Satish', 'pvsssraju@gmail.com', '4/5/2023', '4106038136', '7 REDWOOD PATH', '', 'Senior QA Engineer', 'Nvidia'),
(71, 'Pratima', 'mantena.pratima@gmail.com', '4/5/2023', '4106033141', '7 REDWOOD PATH', '', '', ''),
(72, 'Shashidhar', 'shashikura@yahoo.com', '4/29/2023', '5089042452', '30 Arch St', '', '', ''),
(73, 'Ravi', 'mukthineni@gmail.com', '5/8/2023', '6177926295', '4 Triphammer Rd', '', 'IT Manager', 'Whirlpool'),
(74, 'Madhu', 'madhu.tera@gmail.com', '5/23/2023', '7816403140', '85 Canterbury Hill Rd', '', '', ''),
(75, 'VIJAYAKUMAR', 'vkveeragandham@gmail.com', '5/24/2023', '6052140519', '1 APRIL LN', '', 'Director - Database Services', 'Radiology Partners'),
(76, 'Pattabhi', 'pattabhiy@yahoo.com', '4/1/2023', '2482452465', '6373 Charles Sr', '', '', ''),
(77, 'Krishna', 'chavak28@gmail.com', '4/8/2023', '7346348348', '18490 Clairmont Cir W', '', 'Sr.Principal Database Architect', 'Northrop Grumman'),
(78, 'Narasa Raju', 'narasaraju.penmetsa@gmail.com', '5/3/2023', '2102183912', '1835 Fox Prairie Rd', '', 'DBA', 'BCBS'),
(79, 'Prasad', 'prasad.gunturi@gmail.com', '4/14/2023', '0019526861', '9776 Cupola Ln', '', 'Owner/CEO', 'Aver Technologies, Inc,'),
(80, 'Raghu', 'raghuvadlamudi@comcast.net', '4/19/2023', '6512614685', '727 Lake Ridge Drive', '', 'Director of business development', 'Noblesoft technologies inc '),
(81, 'Manjula', 'manjulavm@gmail.com', '4/9/2023', '6362228319', '264 magnolia trace dr', '', 'Senior Director', 'Verisign'),
(82, 'Pradeep', 'pksomava@yahoo.com', '4/16/2023', '4025177283', '3218 N 168th Ave', '', 'Enterprise Architect ', 'Fiserv'),
(83, 'Rajendra', 'Rajendra.Kottakota@gmail.com', '3/21/2023', '9788061764', '173 Range Rd', '', '', ''),
(84, 'VVA Siva Kumar', 'puvvala.siva@gmail.com', '4/2/2023', '2035545907', '35 Diamondback Ave', '', 'Associate Director, IT', 'Ansell Healthcare'),
(85, 'Anuradha', 'uanuradha@gmail.com', '5/21/2023', '9789851404', '24 Hartwell Brook', '', 'Vice President', 'JPMC'),
(86, 'Harish', 'harish.rayapudi@gmail.com', '3/26/2023', '4085134041', '121 Fountayne Ln', '', 'Software Engineer', 'TCS'),
(87, 'Raju', 'penematcha@gmail.com', '3/28/2023', '7326193164', '3 Angelica ct', '', '', ''),
(88, 'Sruthima', 'mantenasruthi892@gmail.com', '3/29/2023', '2707995252', '27 Galligen Dr', '', 'Software Engineering Manager', 'Adobe'),
(89, 'Raju', 'rdatla007@gmail.com', '3/31/2023', '7325168438', '2 Amy Court', '', '', ''),
(90, 'Kiran', 'kiranvadlani@gmail.com', '4/2/2023', '6032335397', '54 Vincent behan blvd', '', '', ''),
(91, 'Srinivasa', 'chennu@hotmail.com', '4/2/2023', '5715441508', '44 Woodbridge Terrace #4D', '', 'Technical Program Manager', 'Cisco Systems'),
(92, 'Jagannadh', 'jag.kanumuri@aciinfotech.com', '4/3/2023', '7324231139', '5 Gorman Ct', '', 'Lead Solutions Architect', 'NetApp'),
(93, 'Sri Ravi Sankar', 'srigangavarapu@gmail.com', '4/9/2023', '8626864120', '1 Bennington Dr', '', '', 'Meta Platforms Inc'),
(94, 'Suresh', 'kumarbu@gmail.com', '4/15/2023', '+173257028', '52 Vincent Behan Blvd', '', 'Technical Product Owner', 'Delta Air Lines'),
(95, 'Madhuri', 'MadhuriMokarala@gmail.com', '4/16/2023', '7322599452', '174 pleasant run road', '', 'Sr Domain Engineer', 'Sandiego gas and electric'),
(96, 'Sruthima', 'sruthi7755@gmail.com', '4/19/2023', '2707995251', '27 Galligen Dr', '', '', ''),
(97, 'Venkata', 'VvenkatReddy@gmail.com', '4/19/2023', '6785767696', '62 Loft Dr', '', 'Chief Research and Technology Director', 'Donatelle'),
(98, 'Kiran', 'ray@cabsinc.com', '4/19/2023', '7325434865', '40 Devonshire Dr', '', '', ''),
(99, 'Seshagiri', 'asgiribabu@yahoo.com', '4/20/2023', '6099037728', '1 Thoreau Drive', '', 'Lead Business Systems Analyst', 'ValueMomentum '),
(100, 'Satish', 'satish.mantena@gmail.com', '4/21/2023', '+173270503', '17 Hartlander St', '', '', ''),
(101, 'Sarath', 'sarath_kalidindi@yahoo.com', '4/22/2023', '7323061849', '20 York Road', '', '', ''),
(102, 'Prasada', 'pylainfo@gmail.com', '4/23/2023', '2018509668', '1 Balzano Ct', '', 'Assistant Vice President ', 'Deutsche Bank Global '),
(103, 'Praveen', 'rpravi@gmail.com', '4/30/2023', '3135103155', '191 Blue heron dr', '', 'Senior Software Development Manager', 'Amazon'),
(104, 'ANJANEYULU', 'nalabothu1@yahoo.com', '5/1/2023', '7323064962', '25 CINDER ROAD, 2K', '', 'PRINCIPAL ARCHITECT', 'VISION SERVICE PLAN'),
(105, 'sravanalaya', 'naralasettylaya@gmail.com', '5/13/2023', '5715308094', '14 marsh ct', '', 'Engineering leader', 'Adobe'),
(106, 'Anuradha', 'anu.radhask@gmail.com', '5/14/2023', '7329864149', '485 plainfield rd', '', 'Senior Principal Engineer', 'TechnipFMC'),
(157, 'Venkata Ravi Varma', 'ravivarma.gv@gmail.com', '3/28/2023', '4242473874', '14137 Steadman Dr', '', '', ''),
(158, 'Srinivas', 'parupudi_s@hotmail.com', '3/28/2023', '2812530085', '3810 Nottingham Bluff Ln', '', '', 'Equinix'),
(159, 'Ravindra', 'rchalla999@gmail.com', '3/29/2023', '8322078079', '5501 Marina DR', '', '', ''),
(160, 'Krishna', 'krishnadandamudi@yahoo.com', '3/31/2023', '9729797272', '3120 San Simeon Way', '', 'Director, Technical Program Management ', 'Optum Insights'),
(161, 'Jaya Raghavendra Arun Kumar', 'jyellajo@mtu.edu', '3/31/2023', '8326520143', '12655 W Houston Center Blvd', '', 'Faculty', 'Stevens Institute of Technology '),
(162, 'Rajah', 'bkrajah@yahoo.com', '4/1/2023', '3367061270', '8017 HAZELTINE DR', '', '', ''),
(163, 'venkata rajesh', 'rajesh2008ad@gmail.com', '4/1/2023', '+190628189', '4980 usaa blvd', '', 'Director of Engineering', 'Ideal Industries'),
(164, 'Ramakrishnam', 'urskrkraju@gmail.com', '4/2/2023', '6502431897', '2517 Avenue N', '', 'Manager - Full Stack', 'Verizon'),
(165, 'Venkata Sudhakar', 'vkalikay@gmail.com', '4/2/2023', '4088365506', '1301 Bray Central', '', 'Project Delivery Manager', 'Deloitte '),
(166, 'Sakuntala', 'sashi.sagiraju@gmail.com', '4/2/2023', '4694280733', '13561 Bigelow Ln', '', '', 'Genpact'),
(167, 'Ramakrishna', 'ramki.palle@gmail.com', '4/2/2023', '4085373913', '7173 9th Hole Dr', '', 'Feature Lead', 'Bank of America '),
(168, 'Srinivasa', 'sgowru@hotmail.com', '4/4/2023', '4088355769', '12705 Monterey Path', '', '', 'Wells Fargo Bank'),
(169, 'Kalyan', 'kalyan.sirivella@gmail.com', '4/5/2023', '0019197494', '714 Willow Ridge Ct', '', '', ''),
(170, 'Ramakrishna', 'yarkar@gmail.com', '4/10/2023', '6307247810', '921 Panorama Dr', '', 'Program Director', 'Tapestry Inc.'),
(171, 'Jyothi', 'jyothi.panchak@gmail.com', '4/15/2023', '2144185076', '1616 Earhart Ln', '', 'Sr. Delivery Manager', 'EPAM Systems'),
(172, 'Neelima', 'nimmy5@yahoo.com', '4/16/2023', '2562890018', '6823 Entelman Ln', '', 'Sr.software Engineer ', 'IT BlueCross Blue Shield of Nebraska'),
(173, 'Durga vara prasad', 'ucontactraju@gmail.com', '4/19/2023', '7324286912', '225 harbor hills dr', '', 'STAFF ENGINEER', 'INTERRA, INC'),
(174, 'Lalitha', 'lsangana@gmail.com', '4/19/2023', '5124616122', '11200 Savin hill lane', '', 'Integration Developer', ''),
(185, 'Srinivasa', 'sbkunamneni@gmail.com', '3/14/2023', '7032582279', '20348 Medalist Drive', '', 'SAP Project Manager', 'Loudoun Water'),
(186, 'Ravi', 'ravivarma@gmail.com', '3/22/2023', '2157158950', '2492 quick st', '', 'Founder/CEO', 'Camelot'),
(187, 'Sudharani', 'sudhamarupudi@gmail.com', '3/27/2023', '1703350538', '20080 BLACKWOLF RUN PL', '', 'Engineering Manager', 'WorkBoard'),
(188, 'Sattar', 'sattarshaik70@gmail.com', '4/1/2023', '7035877688', '19971 BELMONT STATION DR', '', '', ''),
(189, 'Sreevani', 'vani318@yahoo.com', '4/7/2023', '7037327034', '1902 Dalmation Drive', '', '', ''),
(190, 'Lalitha', 'lalithake@gmail.com', '4/7/2023', '7038619872', '1000 evonshire ln', '', 'Lockheed Martin ', ''),
(191, 'Srini', 'sriniSaranu@gmail.com', '4/8/2023', '5714275365', '21302 southolme way', '', '', ''),
(192, 'Srinivas', 'ssunkara@hotmail.com', '4/9/2023', '5719199265', '44413 Stone Roses Cir', '', '', 'DTE'),
(193, 'Surya Vandana', 'vandanaveluri@gmail.com', '4/12/2023', '7034341394', '13104 Queensdale Dr.', '', 'student', ''),
(194, 'Kalyani', 'kalyaniyellapu@yahoo.com', '4/20/2023', '7039676255', '10450 Artemel Lane', '', 'President', 'Cabs, Inc'),
(195, 'Vijay', 'vijayrr007@gmail.com', '4/27/2023', '7147329472', '24626 Edmond ridge place', '', '', ''),
(196, 'Venkat Raju', 'venkatraju1987@gmail.com', '5/26/2023', '4258294172', '12929 Centrepark Cir', '', '', ''),
(197, 'Satish', 'satishv9@gmail.com', '5/26/2023', '8482023159', '2490 Quick Street', '', 'Engineer', 'JP Morgan Chase'),
(198, 'Sesha Bhavani', 'vijji.soma@gmail.com', '3/31/2023', '4256473351', '4104 220th St SE', '', 'Senior Engineer', 'RWE'),
(199, 'Suneetha', 'sumudunu@gmail.com', '4/2/2023', '6179388714', 'Sammamish', '', '', ''),
(200, 'Eswar', 'EELURI@REVASOLUTIONS.COM', '4/3/2023', '2066176426', '4249 Shoreclub Dr', '', 'Manager - Analytics', 'AMC Theatres'),
(201, 'Satyam', 'satyam.appadwedula@gmail.com', '3/30/2023', '4149152256', 'W194N5691 Deer Park ct', '', '', 'Qualcomm'),
(202, '', '', '5/27/2023', '', '', '', '', ''),
(203, '', '', '7/1/2023', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`content_id`);

--
-- Indexes for table `student_details`
--
ALTER TABLE `student_details`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `teacher_details`
--
ALTER TABLE `teacher_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `content_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `teacher_details`
--
ALTER TABLE `teacher_details`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
