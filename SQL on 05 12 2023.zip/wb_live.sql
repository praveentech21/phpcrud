-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2023 at 12:14 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wb_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `qid` int(11) NOT NULL,
  `op` char(1) NOT NULL,
  `answer` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`qid`, `op`, `answer`) VALUES
(1, 'A', 'Went'),
(1, 'B', 'is going'),
(1, 'C', 'will go'),
(1, 'D', 'going'),
(2, 'A', 'under'),
(2, 'B', 'after'),
(2, 'C', 'over'),
(2, 'D', 'during'),
(3, 'A', 'to'),
(3, 'B', 'by'),
(3, 'C', 'for '),
(3, 'D', 'at'),
(4, 'A', 'between'),
(4, 'B', 'below'),
(4, 'C', 'inside'),
(4, 'D', 'aganist'),
(5, 'A', 'for'),
(5, 'B', 'about'),
(5, 'C', 'without'),
(5, 'D', 'into'),
(6, 'A', 'of'),
(6, 'B', 'without'),
(6, 'C', 'with'),
(6, 'D', 'from'),
(7, 'A', 'under'),
(7, 'B', 'because'),
(7, 'C', 'quickly'),
(7, 'D', 'into'),
(8, 'A', 'by'),
(8, 'B', 'with'),
(8, 'C', 'at'),
(8, 'D', 'from'),
(9, 'A', 'over'),
(9, 'B', 'inside'),
(9, 'C', 'until'),
(9, 'D', 'from'),
(10, 'A', '9'),
(10, 'B', '-9'),
(10, 'C', '5'),
(10, 'D', '-5');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `msg_id` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `pid` varchar(15) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `qid` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL DEFAULT 3,
  `question` varchar(1000) NOT NULL,
  `code` text DEFAULT NULL,
  `answer` char(1) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`qid`, `topic_id`, `question`, `code`, `answer`, `status`, `timestamp`) VALUES
(1, 3, 'she-----to the store yesterday.', '', 'A', 0, '2023-10-07 01:32:38'),
(2, 3, 'The cat gracefully leaped __________ the fence.', '', 'C', 0, '2023-10-07 01:32:44'),
(3, 3, 'His speech was so inspiring that it brought tears __________ my eyes.', '', 'A', 0, '2023-10-07 01:32:32'),
(4, 3, 'The stormy weather forced us to stay __________ home all weekend.', '', 'C', 1, '2023-10-07 01:32:44'),
(5, 3, 'The chef prepared a delicious meal __________ a special occasion.', '', 'A', 0, '2023-10-06 19:05:31'),
(6, 3, 'The musician played the guitar __________ passion and skill.', '', 'C', 0, '2023-10-06 19:07:31'),
(7, 3, 'She searched __________ her lost keys everywhere.', '', 'A', 0, '2023-10-06 19:08:44'),
(8, 3, 'The detective was determined to solve the mystery __________ all costs.', '', 'A', 0, '2023-10-07 01:31:35'),
(9, 3, 'The children played in the park __________ the sun went down.', '', 'C', 0, '2023-10-07 01:29:56'),
(10, 3, 'what is the answer of the following ?', '<p>5+(2^2 + 51/3 - 7*5)</p>', 'B', 0, '2023-10-07 01:10:32');

-- --------------------------------------------------------

--
-- Table structure for table `responses`
--

CREATE TABLE `responses` (
  `sid` varchar(10) NOT NULL,
  `qid` int(11) NOT NULL,
  `answer` char(1) NOT NULL,
  `timestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `responses`
--

INSERT INTO `responses` (`sid`, `qid`, `answer`, `timestamp`) VALUES
('9052727402', 10, 'B', '2023-10-07 01:08:37.751817'),
('9052727402', 9, 'C', '2023-10-07 01:29:36.420571'),
('9052727402', 8, 'D', '2023-10-07 01:29:59.277273'),
('9052727402', 3, 'D', '2023-10-07 01:31:38.680887'),
('9052727402', 1, 'A', '2023-10-07 01:32:34.406823'),
('9052727402', 2, 'C', '2023-10-07 01:32:41.129917'),
('9052727402', 4, 'D', '2023-10-07 01:32:46.491696');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `pid` varchar(10) NOT NULL,
  `pin` varchar(4) DEFAULT NULL,
  `player_name` varchar(100) DEFAULT NULL,
  `place` varchar(200) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `points` int(5) DEFAULT NULL,
  `lastseen` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`pid`, `pin`, `player_name`, `place`, `status`, `points`, `lastseen`) VALUES
('6281261340', '0000', 'Bhavana', 'CSE, Vishnu', 0, 100, '2023-10-03 00:40:30'),
('6302025880', '0000', 'Jyothi Surekha', 'CSE, Vishnu', 0, 100, '2023-03-25 11:08:43'),
('6305762672', '0000', 'akhil', 'pkl, biet', 0, 100, '2023-03-25 10:36:16'),
('7013834973', '0000', 'vinay prasad', 'csd, srkrec', 0, 100, '2023-03-25 10:36:16'),
('7207810916', '0000', 'naveena', 'bvrm, srkrec', 0, 100, '2023-03-25 10:08:35'),
('7382379399', '0000', 'subbarao', 'csd, srkrec', 0, 100, '2023-03-25 10:36:16'),
('7981511233', '0000', 'ravi ', 'pkl , demo', 0, 100, '2023-03-25 09:44:53'),
('8008280898', '0000', 'M.yaswanth', 'bvrm, srkrec', 0, 100, '2023-03-25 06:42:19'),
('8125842676', '0000', 'sumasri', 'bvrm, srkrec', 0, 100, '2023-03-25 10:36:16'),
('8125848047', '0000', 'bhanu ', 'bvrm , srkrec', 0, 100, '2023-03-25 10:36:16'),
('8247347964', '0000', 'p.venkat', 'vijaywada, srkrec', 0, 100, '2023-03-25 06:12:07'),
('8247562235', '0000', 'sirisha', 'bvrm, srkrec', 0, 100, '2023-03-25 09:44:53'),
('8330984689', '0000', 'yakshini ananya', 'bhimavarm, sekrec', 0, 100, '2023-03-25 09:44:53'),
('8522067368', '0000', 'vamsi sir ', 'bvrm, srkrec', 0, 100, '2023-03-25 09:44:53'),
('8686850509', '0000', 'Sathwika', 'CSE, Vishnu', 0, 100, '2023-04-01 07:30:09'),
('8688354549', '0000', 'Rishitha', 'CSE, Vishnu', 0, 100, '2023-04-01 07:30:09'),
('8712711814', '0000', 'rayudu', 'tanuku, srkrec', 0, 100, '2023-03-25 06:42:19'),
('8919259699', '0000', 'Gracy', 'CSD, Srkrec', 0, 100, '2023-03-25 06:12:07'),
('8977292778', '0000', 'lavanya duddukuri', 'bvrm, srkrec', 0, 100, '2023-04-01 07:30:09'),
('9014743819', '0000', 'aravindh', 'bvrm, srkrec', 0, 100, '2023-03-25 08:02:25'),
('9032909010', '0000', 'sudheer', 'bvrm, srkrec', 0, 100, '2023-03-25 10:36:16'),
('9052727402', '0000', NULL, NULL, 0, NULL, '2023-10-07 05:25:35'),
('9059670613', '0000', 'Pranathi ', 'Csd, Srkrec', 0, 100, '2023-03-25 06:12:07'),
('9121472127', '0000', 'Asritha', 'CSE, Vishnu', 0, 100, '2023-04-01 07:30:09'),
('9346610887', '0000', 'bharani', 'bvrm, srkrec', 0, 100, '2023-03-25 09:44:53'),
('9347394181', '0000', 'shailandhar', 'bvrm, srkrec', 0, 100, '2023-03-25 07:34:58'),
('9392053297', '0000', 'asritha', 'bvrm, srkrec', 0, 100, '2023-03-25 07:15:46'),
('9392597082', '0000', 'sashank', 'bvrm, srkrec', 0, 100, '2023-03-25 08:02:25'),
('9392768944', '0000', 'rajesh nayak .l', 'bvrm , srkrec', 0, 100, '2023-03-25 08:02:25'),
('9398722472', '0000', 'Uma Subhashini R', 'CSD, SRKREC', 0, 100, '2023-04-01 07:30:09'),
('9398954816', '0000', 'karthik', 'pkl, srkrec', 1, 100, '2023-10-03 03:33:34'),
('9490231222', '0000', 'teja ', 'bvrm, srkrec', 0, 100, '2023-03-25 08:02:25'),
('9491998159', '0000', 'sai trilok', 'bvrm, srkrec', 0, 100, '2023-03-25 07:34:58'),
('9494714567', '0000', 'oujasya', 'bvrm , srkrec', 0, 100, '2023-03-25 08:02:25'),
('9550451972', '0000', 'vathsalya ', 'bvrm, srkrec', 0, 100, '2023-03-25 07:34:58'),
('9618882624', '0000', 'abhi', 'bvrm, srkrec', 0, 100, '2023-03-25 06:12:07'),
('9704407429', '0000', 'vivek', 'csd, srkrec', 0, 100, '2023-03-25 10:36:16'),
('9848823311', '0000', 'k. sanju ', 'csd, srkrec', 0, 100, '2023-03-25 10:36:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`qid`,`op`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `responses`
--
ALTER TABLE `responses`
  ADD PRIMARY KEY (`sid`,`qid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
